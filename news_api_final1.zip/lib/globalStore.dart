import 'dart:async';
import 'dart:core' as prefix0;
import 'dart:core';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';


final FirebaseAuth _auth = FirebaseAuth.instance;
final GoogleSignIn googleSignIn = GoogleSignIn();
final databaseReference = FirebaseDatabase.instance.reference();
var userDatabaseReference;
var articleSourcesDatabaseReference;
var articleDatabaseReference;
GoogleSignInAccount guser;
DataSnapshot snapshot;

Future<FirebaseUser> signInWithGoogle() async {

  final GoogleSignInAccount googleSignInAccount = await googleSignIn.signIn();
  final GoogleSignInAuthentication googleSignInAuthentication = await googleSignInAccount.authentication;

  final AuthCredential credential = GoogleAuthProvider.getCredential( 
    accessToken: googleSignInAuthentication.accessToken,
    idToken: googleSignInAuthentication.idToken
  );

  final FirebaseUser user = await _auth.signInWithCredential(credential);
  print("Signed In" + user.displayName);

  assert(!user.isAnonymous);
  assert(await user.getIdToken() != null);

  final FirebaseUser currentUser = await _auth.currentUser();
  assert(user.uid == currentUser.uid);
 /*
  final FirebaseApp app  = FirebaseApp( 
      options: FirebaseOptions(
      googleAppID: '1:288853841294:android:c6fba533d355473b',
      apiKey: 'AIzaSyCjYHx0QfN3d7wrUoMmlyX8uPo3N9sevrA' ,
      databaseURL:'https://newsapi-final.firebaseio.com' ,
     )
  );
*/

  if( user != null ){
    guser = await googleSignIn.signIn();
    userDatabaseReference = databaseReference.child(guser.id);
    articleDatabaseReference = databaseReference.child(guser.id).child('articles');
    articleSourcesDatabaseReference = databaseReference.child(guser.id).child('sources');
  }

  if(await _auth.currentUser() == null) {
    

  }
 

}



var logIn = signInWithGoogle();